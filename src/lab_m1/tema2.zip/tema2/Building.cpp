#include "Building.h"

Building::Building()
{
	xpos = 0;
	ypos = 0;
	zpos = 0;
	rot = 0;
	scale = glm::vec3(0);
}

Building::Building(float x, float y, float z, float r, glm::vec3 s)
{
	xpos = x;
	ypos = y;
	zpos = z;
	rot = r;
	scale = s;
}

void Building::setX(float t)
{
	xpos = t;
}

void Building::setY(float t)
{
	ypos = t;
}

void Building::setZ(float t)
{
	zpos = t;
}

void Building::setRot(float t)
{
	rot = t;
}

void Building::setScale(glm::vec3 t)
{
	scale = t;
}

float Building::getX()
{
	return xpos;
}

float Building::getY()
{
	return ypos;
}

float Building::getZ()
{
	return zpos;
}

float Building::getRot()
{
	return rot;
}

glm::vec3 Building::getScale()
{
	return scale;
}
