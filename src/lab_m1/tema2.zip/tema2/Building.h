#pragma once
#include <glm/glm.hpp>

class Building
{
private:
	float xpos;
	float ypos;
	float zpos;
	float rot;
	glm::vec3 scale;

public:
	Building();
	Building(float x, float y, float z, float r, glm::vec3 s);
	void setX(float t);
	void setY(float t);
	void setZ(float t);
	void setRot(float t);
	void setScale(glm::vec3 t);
	float getX();
	float getY();
	float getZ();
	float getRot();
	glm::vec3 getScale();
};